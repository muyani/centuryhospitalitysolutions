
/*
 * Editor client script for DB table customers1
 * Created by http://editor.datatables.net/generator
 */

(function($){

$(document).ready(function() {
	var editor = new $.fn.dataTable.Editor( {
		ajax: 'php/table.customers1.php',
		table: '#customers1',
		fields: [
			{
				"label": "customer name :",
				"name": "customer_name_",
				"def": "John Okonkwo"
			},
			{
				"label": "Customer Phone:",
				"name": "customer_phone",
				"def": "0706277341"
			},
			{
				"label": "Customer Email:",
				"name": "customer_email",
				"def": "example@gmail.com"
			},
			{
				"label": "Customer Status:",
				"name": "customer_status",
				"type": "select",
				"def": "pending",
				"options": [
					"pending",
					"followup",
					"settled"
				]
			},
			{
				"label": "Customer Message:",
				"name": "customer_message",
				"type": "textarea",
				"def": "Enter the message left by customer"
			}
		]
	} );

	var table = $('#customers1').DataTable( {
		dom: 'Bfrtip',
		ajax: 'php/table.customers1.php',
		columns: [
			{
				"data": "customer_name_"
			},
			{
				"data": "customer_phone"
			},
			{
				"data": "customer_email"
			},
			{
				"data": "customer_status"
			},
			{
				"data": "customer_message"
			}
		],
		select: true,
		lengthChange: false,
		buttons: [
			{ extend: 'create', editor: editor },
			{ extend: 'edit',   editor: editor },
			{ extend: 'remove', editor: editor }
		]
	} );
} );

}(jQuery));

